WildFusion GO — Balanced Omega Boss update

Upload index.html to the root of your existing GitHub Pages repository, replacing the old file.

Changes: original 24 fixed fusion recipes plus 3 Apex recipes; no arbitrary fusion pairs; Omega Behemoth has 750 HP, attacks for 75–100 damage and takes normal damage from all creatures. Apex fighters remain strongest. Existing username saves remain under the same browser keys. Old arbitrary fusions are retired and no longer selectable. Creature stats remain fixed.
